﻿namespace abdinour_hassan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.femaleradio = new System.Windows.Forms.RadioButton();
            this.male = new System.Windows.Forms.RadioButton();
            this.stdagetextBox = new System.Windows.Forms.TextBox();
            this.stdIdtextBox = new System.Windows.Forms.TextBox();
            this.stdNametextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.std_namel = new System.Windows.Forms.Label();
            this.courseslist = new System.Windows.Forms.ListBox();
            this.Extra_curricular = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.resultlabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Controls.Add(this.femaleradio);
            this.groupBox1.Controls.Add(this.male);
            this.groupBox1.Controls.Add(this.stdagetextBox);
            this.groupBox1.Controls.Add(this.stdIdtextBox);
            this.groupBox1.Controls.Add(this.stdNametextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.std_namel);
            this.groupBox1.Location = new System.Drawing.Point(367, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(294, 200);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " student info";
            // 
            // femaleradio
            // 
            this.femaleradio.AutoSize = true;
            this.femaleradio.Location = new System.Drawing.Point(169, 176);
            this.femaleradio.Name = "femaleradio";
            this.femaleradio.Size = new System.Drawing.Size(62, 17);
            this.femaleradio.TabIndex = 5;
            this.femaleradio.TabStop = true;
            this.femaleradio.Text = " Female";
            this.femaleradio.UseVisualStyleBackColor = true;
            // 
            // male
            // 
            this.male.AutoSize = true;
            this.male.Location = new System.Drawing.Point(47, 176);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(51, 17);
            this.male.TabIndex = 1;
            this.male.TabStop = true;
            this.male.Text = " Male";
            this.male.UseVisualStyleBackColor = true;
            // 
            // stdagetextBox
            // 
            this.stdagetextBox.Location = new System.Drawing.Point(120, 115);
            this.stdagetextBox.Name = "stdagetextBox";
            this.stdagetextBox.Size = new System.Drawing.Size(147, 20);
            this.stdagetextBox.TabIndex = 4;
            // 
            // stdIdtextBox
            // 
            this.stdIdtextBox.Location = new System.Drawing.Point(121, 72);
            this.stdIdtextBox.Name = "stdIdtextBox";
            this.stdIdtextBox.Size = new System.Drawing.Size(147, 20);
            this.stdIdtextBox.TabIndex = 3;
            // 
            // stdNametextBox
            // 
            this.stdNametextBox.Location = new System.Drawing.Point(121, 37);
            this.stdNametextBox.Name = "stdNametextBox";
            this.stdNametextBox.Size = new System.Drawing.Size(147, 20);
            this.stdNametextBox.TabIndex = 1;
            this.stdNametextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(17, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "  Student Age";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(17, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "  Student ID";
            // 
            // std_namel
            // 
            this.std_namel.Location = new System.Drawing.Point(17, 37);
            this.std_namel.Name = "std_namel";
            this.std_namel.Size = new System.Drawing.Size(116, 23);
            this.std_namel.TabIndex = 0;
            this.std_namel.Text = " Student name";
            // 
            // courseslist
            // 
            this.courseslist.FormattingEnabled = true;
            this.courseslist.Items.AddRange(new object[] {
            "c++",
            "java",
            "html"});
            this.courseslist.Location = new System.Drawing.Point(367, 300);
            this.courseslist.Name = "courseslist";
            this.courseslist.Size = new System.Drawing.Size(120, 82);
            this.courseslist.TabIndex = 1;
            // 
            // Extra_curricular
            // 
            this.Extra_curricular.Location = new System.Drawing.Point(506, 328);
            this.Extra_curricular.Name = "Extra_curricular";
            this.Extra_curricular.Size = new System.Drawing.Size(119, 24);
            this.Extra_curricular.TabIndex = 2;
            this.Extra_curricular.Text = " Extra-curricular";
            this.Extra_curricular.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(367, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = " Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(459, 388);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = " Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(560, 388);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // resultlabel
            // 
            this.resultlabel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.resultlabel.Location = new System.Drawing.Point(365, 425);
            this.resultlabel.Name = "resultlabel";
            this.resultlabel.Size = new System.Drawing.Size(271, 95);
            this.resultlabel.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::abdinour_hassan.Properties.Resources.RUKUMO_02;
            this.pictureBox1.Location = new System.Drawing.Point(368, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(268, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(981, 529);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.resultlabel);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Extra_curricular);
            this.Controls.Add(this.courseslist);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox stdNametextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label std_namel;
        private System.Windows.Forms.RadioButton femaleradio;
        private System.Windows.Forms.RadioButton male;
        private System.Windows.Forms.TextBox stdagetextBox;
        private System.Windows.Forms.TextBox stdIdtextBox;
        private System.Windows.Forms.ListBox courseslist;
        private System.Windows.Forms.CheckBox Extra_curricular;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label resultlabel;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

